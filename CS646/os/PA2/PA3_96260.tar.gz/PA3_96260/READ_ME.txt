This is a "High-Level" Simulator.

Please note that if you see something that looks like an additional
feature, it may just be the preparations for an additional feature, so
you may not find the feature itself.

When running this program, please note that it accepts 2 command line
arguments: the first one being the configurations file name, and the
second being the meta-data file name.
Ex: ./a.out my_config_file my_meta_data_file

Also please note that this program uses real time for timing, so please
use meta-data according to how long a program run should take.


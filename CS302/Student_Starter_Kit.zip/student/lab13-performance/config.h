/**
 * Timer class (Lab 13) configuration file.
 * Activate test 'N' by defining the corresponding LAB12_TESTN to have the value 1.
 */

#define LAB13_TEST1	0		// 
#define LAB13_TEST2	0		// 


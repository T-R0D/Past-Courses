/**
 * Linked List class (Lab 5) configuration file.
 * Activate test #N by defining the corresponding LAB5_TESTN to have the value 1.
 */

#define LAB5_TEST1	0	// 1 means test with int instead of char
#define LAB5_TEST2	0	// Activate moveToBeginning (prog exercise 2)
#define LAB5_TEST3	0	// Activate insertBefore (prog exercise 3)


/**
 * Heap class configuration file.
 * Activate test #N by defining the corresponding LAB11_TESTN to have the value 1.
 */

#define LAB11_TEST1	0		// Programming Exercise 3: writeLevels


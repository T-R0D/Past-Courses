#define LAB2_TEST1	0		// Date constructors
#define LAB2_TEST2	0		// Date getters
#define LAB2_TEST3	0		// isLeapYear
#define LAB2_TEST4	0		// daysInMonth
#define LAB2_TEST5	0		// Date operator<<
#define LAB2_TEST6	0		// BlogEntry constructors
#define LAB2_TEST7	0		// BlogEntry getters/setters
#define LAB2_TEST8	0		// Exercise 1 - printHTML
#define LAB2_TEST9	0		// Exercise 2 - getDayOfWeek
#define LAB2_TEST10	0		// Exercise 3 - Date relational operators
